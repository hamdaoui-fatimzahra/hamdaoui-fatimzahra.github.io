package com.boudaa.tools;

public class TestMoyenneException  extends  Exception{

	public TestMoyenneException() {
		super();
	}
	public TestMoyenneException(String message) {
		super(message);
	}
}