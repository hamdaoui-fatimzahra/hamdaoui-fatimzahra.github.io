package com.boudaa.tools;

public class TestValidationException extends Exception{
	public TestValidationException() {
		super();
	}
	public TestValidationException(String message) {
		super(message);
	}

}
