package com.boudaa.tools;


public class TestNotesElementsException  extends  Exception{

	public TestNotesElementsException() {
		super();
	}
	public TestNotesElementsException(String message) {
		super(message);
	}
}
