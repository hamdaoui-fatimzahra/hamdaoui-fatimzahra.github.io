import org.springframework.beans.factory.annotation.Autowired;
import com.gsnotes.services.*;
import com.gsnotes.dao.IUtilisateurDao;

public class Test {
	
	@Autowired
	private IPersonService IPersonService;
	
	public static void main(String [] args) {
		
	}

}
